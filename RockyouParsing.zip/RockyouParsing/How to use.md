# How to use this script

This script is used to convert the rock you list into JSON.

1. Place the `rockyou.txt` file in the same folder than the script.
2. Run `python2 a.py` to convert the file.
3. Copy the `rockyou.json` into the `/app/assets` folder of the project