import string

# Open the file for reading
with open("rockyou.txt", "r") as file:
    # Read all lines from the file
    lines = file.readlines()


def recursiveReplace(str):
    s = str.replace('\\', '').replace('"', '\\"')
    
    return s
# Add quotation marks and comma to each line
lines = ['"' + recursiveReplace(line.strip()) + '"' for line in lines if all(char in string.printable for char in line)]
#for i, str in enumerate(lines):
#    while "" in str:
#        lines[i] = str.replace('""', '"')
    

lines = [line for line in lines if len(line) > 1]

# Enclose all lines within square brackets
output = '[' + ',\n'.join(lines) + ']'

# Print or write the output to a new file
# print(output)
# If you want to write the output to a new file
with open("rockyou.json", "w") as file:
    file.write(output)
